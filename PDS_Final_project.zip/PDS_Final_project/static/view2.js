console.log("Entered view 2")
//let username = null;
document.addEventListener("DOMContentLoaded", function () {
    const view = document.querySelector("#view2");
    const header = view.querySelector("header");
    const canvas = view.querySelector("#deviceConsumptionChart");
    const dateSelectionForm = view.querySelector("#monthYearSelectionForm");
    username = document.querySelector("#view2").getAttribute("data-username");
    console.log("My user name in view 2 is ",username);
    // Function to toggle the view's visibility and the elements inside it
    function toggleView() {
        view.classList.toggle("collapsed");
        canvas.classList.toggle("hidden");
        dateSelectionForm.classList.toggle("hidden");
        if (deviceChart) {
            deviceChart.destroy();
        }  
    }

    // Add a click event listener to the header element
    header.addEventListener("click", toggleView);
    
    // Prevent clicking on the canvas or form from propagating to the header click event
    canvas.addEventListener("click", function (e) {
        e.stopPropagation();
    });
    dateSelectionForm.addEventListener("click", function (e) {
        e.stopPropagation();
    });
});
document.getElementById('monthYearSelectionForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const selectedMonth = document.getElementById('monthSelect').value;
    const selectedYear =  document.getElementById('yearInput').value;
    //username="{{ username }}";
    console.log(username);
    fetchDeviceConsumptionData(selectedMonth,selectedYear,username);
});

let deviceChart = null; // Global variable for the bar chart

function fetchDeviceConsumptionData(month,year,username) {
    // Adjust the endpoint URL as needed
    fetch(`/get-device-consumption-data/${username}?month=${month}&year=${year}`)
        .then(response => response.json())
        .then(data => updateDeviceChart(data))
        .catch(error => console.error('Error:', error));
}

function updateDeviceChart(data) {
    const ctx = document.getElementById('deviceConsumptionChart').getContext('2d');
    if (deviceChart) {
        deviceChart.destroy(); // Destroy the previous chart instance
    }
    deviceChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.labels, // e.g., names of the devices
            datasets: [{
                label: 'Device Energy Consumption',
                data: data.values, // e.g., energy consumption values
                backgroundColor: 'lightgrey',
                borderColor: 'black',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}