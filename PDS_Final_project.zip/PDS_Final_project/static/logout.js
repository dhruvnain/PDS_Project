document.addEventListener("DOMContentLoaded", function() {
    const logoutButton = document.getElementById("logoutButton");
    if(logoutButton) {
        logoutButton.addEventListener("click", function() {
            // Make a request to the server to log the user out
            fetch('/logout', {
                method: 'POST', // or 'GET', as per your server setup
                redirect: 'follow'  // Ensure fetch follows the server redirect
            })
            .then(response => {
                // Check if the logout was successful
                if (response.redirected) {
                    window.location.href = response.url; // Follow the redirect URL from the response
                } else {
                    console.error('Logout failed');
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    }
});

