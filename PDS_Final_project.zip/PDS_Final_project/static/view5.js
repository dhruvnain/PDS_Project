console.log("Entered view5.js");
var pieChart = null; // Variable to hold the pie chart instance

document.addEventListener("DOMContentLoaded", function () {
    const view = document.querySelector("#view5"); // Change the ID to view5
    const header = view.querySelector("header");
    const canvas = view.querySelector("#userVsAllPieChart");
    user = view.getAttribute("data-username");
    console.log("My user name in view 5 is ", user);

    // Function to toggle the view's visibility and the elements inside it
    function toggleView() {
        view.classList.toggle("collapsed");
        canvas.classList.toggle("hidden");
        if (pieChart) {
            pieChart.destroy();
        }
    }

    // Add a click event listener to the header element
    header.addEventListener("click", toggleView);

    // Prevent clicking on the canvas or form from propagating to the header click event
    canvas.addEventListener("click", function (e) {
        e.stopPropagation();
    });
});

document.getElementById('chartForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent form from submitting normally

    // Replace "{{ username }}" with the actual username if using a template engine
    var username = user; 

    fetchPieChartData(username); // Call the function to fetch data and update the chart
});

function fetchPieChartData(username) {
    fetch('/display-pie-chart/' + username)
        .then(response => response.json())
        .then(data => {
            if (data.length >= 2) {
                updateUserVsAllChart(data[0], data[1]);
            }
        })
        .catch(error => console.error('Error:', error));
}

function updateUserVsAllChart(userEnergy, allEnergy) {
    const ctx = document.getElementById('userVsAllPieChart').getContext('2d');

    if (pieChart) {
        pieChart.destroy();
    }

    pieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Your Consumption', 'Other Users Consumption'],
            datasets: [{
                data: [userEnergy, allEnergy - userEnergy],
                backgroundColor: [
                    'white',
                    'black'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: false,
            maintainAspectRatio: true,
            title: {
                display: true,
                text: 'Energy Consumption Comparison'
            }
        }
    });

    document.getElementById('userVsAllPieChart').style.display = 'block'; // Show the chart canvas
}
