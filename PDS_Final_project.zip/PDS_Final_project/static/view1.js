// JavaScript to handle form submission and chart update will go here
console.log("Enterted the view1.js file")
let username = null;
document.addEventListener("DOMContentLoaded", function () {
    const view1 = document.querySelector("#view1");
    const header = view1.querySelector("header");
    const canvas = view1.querySelector("#energyChart");
    const dateSelectionForm = view1.querySelector("#dateSelectionForm");
    username = document.querySelector("#view1").getAttribute("data-username");
    console.log("My user name is clicked",username);
    // Function to toggle the view's visibility and the elements inside it
    function toggleView() {
        view1.classList.toggle("collapsed");
        canvas.classList.toggle("hidden");
        dateSelectionForm.classList.toggle("hidden");
        if (chart) {
            chart.destroy();
        }
     
    }

    // Add a click event listener to the header element
    header.addEventListener("click", toggleView);
    
    // Prevent clicking on the canvas or form from propagating to the header click event
    canvas.addEventListener("click", function (e) {
        e.stopPropagation();
    });
    dateSelectionForm.addEventListener("click", function (e) {
        e.stopPropagation();
    });
});

document.getElementById('dateSelectionForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            //const username = document.querySelector("#view1").getAttribute("data-username");
            //username="{{ username }}";
            console.log("My user name is",username);
            console.log("startdate",startDate);
            console.log("endDate",endDate)
            fetchEnergyData(startDate, endDate,username);
        });

        let chart = null; // Global variable for the chart

        function fetchEnergyData(startDate, endDate,username) {
            // Fetch data from Flask route (adjust the endpoint as needed)
            fetch(`/get-energy-data/${username}?start=${startDate}&end=${endDate}`)
                .then(response => response.json())
                .then(data => updateChart(data))
                .catch(error => console.error('Error:', error));
        }

        function updateChart(data) {
            const ctx = document.getElementById('energyChart').getContext('2d');
            if (chart) {
                chart.destroy(); // Destroy the previous chart instance
            }
            chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.labels, // e.g., dates
                    datasets: [{
                        label: 'Energy Consumption',
                        data: data.values, // e.g., energy values
                        // Additional styling...
                        borderColor: 'black', // Line color
                        backgroundColor: 'lightgrey', // Fill color
                        pointBackgroundColor: 'red', // Point color
                        borderWidth: 2, // Line width
                    }]
                }
                
            });
        }
