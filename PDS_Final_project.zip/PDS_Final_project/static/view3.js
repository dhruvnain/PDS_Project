console.log("Entered view3.js");
let deviceCharts_1 = [];

document.addEventListener("DOMContentLoaded", function () {
    const view = document.querySelector("#view3");
    const header = view.querySelector("header");
    user = view.getAttribute("data-username");
    console.log("My user name in view 3 is ", user);

    // Function to toggle the view's visibility and the elements inside it
    function toggleView() {
        console.log("View 4 toggle");
        view.classList.toggle("collapsed");
        deviceCharts_1.forEach(chart => chart.destroy()); // Destroy all existing charts
        deviceCharts_1 = []; // Reset the deviceCharts_1 array
    }

    // Add a click event listener to the header element
    header.addEventListener("click", toggleView);
});

document.addEventListener("DOMContentLoaded", (event) => {
    fetch(`/get_device_address_data/${user}`)
        .then((response) => response.json())
        .then((data) => {
            const select = document.getElementById("serviceLocationSelects");
            console.log(data);
            // Add a default option as the first item
            const defaultOption = document.createElement("option");
            defaultOption.textContent = "Select an option";
            defaultOption.value = "";
            select.appendChild(defaultOption);
            data.forEach((item) => {
                const parts = item.split(':');
                const details = parts.slice(1).join(':').trim();
                const option = document.createElement("option");
                option.value = item;
                option.textContent = details;
                select.appendChild(option);
            });
        })
        .catch((error) => console.error("Error:", error));
});

function updateBarChart2() {
    const selectedLocation = document.getElementById("serviceLocationSelects").value;
    fetch(`/get_savings_data/${user.trim()}?selectedLocation=${encodeURIComponent(selectedLocation)}`)
        .then(response => response.json())
        .then(data => {
            const chartContainer = document.getElementById("chartContainer");
            chartContainer.innerHTML = ''; // Clear existing charts
            deviceCharts_1.forEach(chart => chart.destroy()); // Destroy all existing charts
            deviceCharts_1 = []; // Reset the deviceCharts_1 array

            data.labels.forEach((labels, index) => {
                const values = data.values[index];
                const canvas = document.createElement('canvas');
                canvas.id = 'barChart' + index;
                chartContainer.appendChild(canvas);

                const ctx = canvas.getContext("2d");
                const newChart = new Chart(ctx, {
                    type: "bar",
                    data: {
                        labels: labels,
                        datasets: [{
                            label: `Cost for Set ${index + 1}`,
                            data: values,
                            backgroundColor: ["#333333", "#666666"],
                            borderColor: ["black"],
                            borderWidth: 1,
                        }],
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true,
                            },
                        },
                    },
                });
                deviceCharts_1.push(newChart);
            });
        })
        .catch(error => console.error("Error:", error));
}

function createBarChart(canvasId, labels, values, chartLabel) {
    const ctx = document.getElementById(canvasId).getContext("2d");
    const newChart = new Chart(ctx, {
        type: "bar",
        data: {
            labels: labels,
            datasets: [{
                label: chartLabel,
                data: values,
                backgroundColor: ["#333333", "#666666"],
                borderColor: ["black"],
                borderWidth: 1,
            }],
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                },
            },
        },
    });
    return newChart;
}
