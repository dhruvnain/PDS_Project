document.addEventListener("DOMContentLoaded", function() {
    const homeButton = document.getElementById("homeButton");
    const homeContainer = document.querySelector('.home');
    
    if (homeButton && homeContainer) {
        const username = homeContainer.getAttribute('data-username');

        homeButton.addEventListener("click", function() {
            // Navigate to the /home/<username> route
            window.location.href = `/home/${username}`;
        });
    }
});


