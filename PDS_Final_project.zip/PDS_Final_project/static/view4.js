console.log("Entered view4.js");
let user = null;
let deviceCharts = null;

document.addEventListener("DOMContentLoaded", function () {
    const view = document.querySelector("#view4");
    const header = view.querySelector("header");
    const canvas = view.querySelector("#barChart");
    //const selects = view.querySelector("serviceLocationSelect");
    user = view.getAttribute("data-username");
    console.log("My user name in view 4 is ", user);

    // Function to toggle the view's visibility and the elements inside it
    function toggleView() {
        console.log("View 4 toggle");
        view.classList.toggle("collapsed");
        canvas.classList.toggle("hidden");
        if (deviceCharts) {
            deviceCharts.destroy();
        }
    }

    // Add a click event listener to the header element
    header.addEventListener("click", toggleView);

    // Prevent clicking on the canvas from propagating to the header click event
    canvas.addEventListener("click", function (e) {
        e.stopPropagation();
    });
});

document.addEventListener("DOMContentLoaded", (event) => {
    fetch(`/get_service_locations/${user}`)
        .then((response) => response.json())
        .then((data) => {
            const select = document.getElementById("serviceLocationSelect");
            console.log("view 4 ",data);
            data.forEach((item) => {
                const option = document.createElement("option");
                option.value = item[0];
                option.textContent = item[1] + " " + item[2] + " " + item[3] + " " + item[4];
                select.appendChild(option);
            });
        })
        .catch((error) => console.error("Error:", error));
});

function updateBarChart() {
    const selectedLocation = document.getElementById("serviceLocationSelect").value;
    fetch(`/get_device_data/${user.trim()}?selectedLocation=${selectedLocation}`)
        .then((response) => response.json())
        .then((deviceData) => {
            // Adjusting to the new data format for a bar chart
            const data = {
                labels: deviceData.map((item) => item.device_type),
                datasets: [
                    {
                        label: "Device Count",
                        data: deviceData.map((item) => item.count),
                        backgroundColor: ["#333333", "#666666", "#999999", "#CCCCCC", "#E5E5E5", "#F2F2F2"],
                        borderColor: ["black"], // Border color for each bar
                        borderWidth: 1,
                    },
                ],
            };
            console.log("Device data", data);

            const ctx = document.getElementById("barChart").getContext("2d");

            // Check if a chart instance already exists. If it does, update it; otherwise, create a new chart
            if (deviceCharts) {
                deviceCharts.data.labels = data.labels;
                deviceCharts.data.datasets[0].data = data.datasets[0].data;
                deviceCharts.data.datasets[0].backgroundColor = data.datasets[0].backgroundColor;
                deviceCharts.update();
            } else {
                deviceCharts = new Chart(ctx, {
                    type: "bar",
                    data: data,
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true,
                            },
                        },
                    },
                });
            }
        })
        .catch((error) => console.error("Error:", error));
}
