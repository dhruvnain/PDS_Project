import psycopg2

# Replace the following variables with your actual database credentials
hostname = 'localhost'  # or your server IP
database = 'Final_project'
username = 'postgres'
password = 'postgres'
port_id = 5432  # default PostgreSQL port

# Establishing the connection
conn = psycopg2.connect(
    host=hostname, 
    dbname=database, 
    user=username, 
    password=password, 
    port=port_id
)

# Creating a cursor object using the cursor() method
cursor = conn.cursor()

# Executing an SQL function using the execute() method
cursor.execute("SELECT version();")

# Fetch a single row using fetchone() method.
data = cursor.fetchone()
print("Connection established to: ", data)

cursor.execute("SELECT * FROM customers;")
row = cursor.fetchone()
while row is not None:
    print(row)
    row  = cursor.fetchone()
# Closing the connection
cursor.close()
conn.close()
