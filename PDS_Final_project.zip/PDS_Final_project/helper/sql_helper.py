import psycopg2
import os

# If you use environment variables for database configuration, ensure they are set in your environment.
# If the DATABASE_URL is not set in the environment, it will use the default parameters below.
DATABASE_URL = os.environ.get('DATABASE_URL', 'dbname=Final_project user=postgres password=postgres host=localhost port=5432')

def get_db():
    conn = psycopg2.connect(DATABASE_URL)
    return conn

def query_db(query, args=(), one=False):
    conn = get_db()
    cur = conn.cursor()
    cur.execute(query, args)
    rv = cur.fetchall()
    cur.close()
    conn.close()
    return (rv[0] if rv else None) if one else rv

def insert_db(query, args=()):
    conn = get_db()
    cur = conn.cursor()
    try:
        cur.execute(query, args)
        conn.commit()
    except Exception as e:
        conn.rollback()
    finally:
        cur.close()
        conn.close()

def drop_table(table_name):
    conn = get_db() 
    cur = conn.cursor()
    try:
        cur.execute(f"DROP TEMPORARY TABLE IF EXISTS {table_name};")
        conn.commit()
    except Exception as e:
        print(f"An error occurred: {e}")
        conn.rollback()
    finally:
        cur.close()
        conn.close()


def delete_from_db(query, args=()):
    conn = get_db()  # Assuming get_db() is a function that returns a database connection
    cur = conn.cursor()
    try:
        cur.execute(query, args)
        conn.commit()
    except Exception as e:
        conn.rollback()
    finally:
        cur.close()
        conn.close()
