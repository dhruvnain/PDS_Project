query1 = "SELECT * FROM customers WHERE username = %s"
query2="SELECT * FROM customers WHERE password = %s"
query3="SELECT customerid FROM customers WHERE username = %s"
query4="SELECT MAX(customerid) FROM customers"
query5="INSERT INTO customers (customerid, firstname, lastname, username, password) VALUES (%s, %s, %s, %s, %s)"
query6="SELECT username FROM customers WHERE customerid = %s"
query7="SELECT MAX(addressid) FROM address"
query8="SELECT MAX(locationid) FROM servicelocations"
query9="SELECT COUNT(*) FROM address WHERE addressline1 = %s AND addressline2 = %s AND city = %s AND state = %s AND country = %s  AND zipcode = %s"
query10="INSERT INTO address(addressid, addressline1,addressline2, city,state,country,zipcode, isbilling) VALUES (%s, %s, %s, %s, %s,%s, %s, %s)"
query11="INSERT INTO servicelocations(locationid,customerid,addressid,unitnumber,startdate,squarefootage,bedrooms,occupants) VALUES (%s, %s, %s, %s, %s,%s, %s, %s)"
query12="SELECT COUNT(*) FROM address WHERE addressline1 = %s AND addressline2 = %s AND city = %s AND state = %s AND country = %s  AND zipcode = %s"
query13="INSERT INTO address(addressid, addressline1,addressline2, city,state,country,zipcode, isbilling) VALUES (%s, %s, %s, %s, %s,%s, %s, %s)"
query14="SELECT addressid FROM servicelocations WHERE customerid = %s"
query15="SELECT (addressid,addressline1,addressline2, city,state,country,zipcode) FROM address WHERE addressid = %s"
query16="SELECT locationid from servicelocations where addressid=%s"
query17="SELECT deviceid from devices where locationid=%s"
query18="DELETE from deviceevents where deviceid=%s"
query19="DELETE from devices where deviceid=%s"
query20="DELETE from servicelocations where locationid=%s"
query21="DELETE from address where addressid=%s"
query22="SELECT addressid FROM servicelocations WHERE customerid = %s"
query23="SELECT DISTINCT type,modelnumber FROM devicemodels"
query24="SELECT (addressid,addressline1,addressline2, city,state,country,zipcode) FROM address WHERE addressid = %s"
query25="SELECT MAX(deviceid) FROM devices"
query26="INSERT INTO devices (deviceid,locationid,type,modelnumber) VALUES (%s,%s,%s,%s)"
query27="SELECT locationid FROM servicelocations WHERE customerid = %s"
query28="SELECT addressid FROM servicelocations WHERE locationid = %s"
query29="SELECT (addressline1,addressline2, city,state,country,zipcode) FROM address WHERE addressid = %s"
query30="SELECT (deviceid,type,modelnumber) FROM devices WHERE locationid = %s"
query31="DELETE from deviceevents where deviceid=%s"
query32="DELETE from devices where deviceid=%s"
query33="""
   SELECT EXTRACT(DAY FROM timestamp) AS day, SUM(CAST(value AS FLOAT)) AS total_energy 
    FROM deviceevents de
	join devices d on d.deviceid = de.deviceid
	join servicelocations se on se.locationid = d.locationid
    join customers c on c.customerid =  se.customerid
    WHERE timestamp BETWEEN %s AND %s and c.username = %s
    GROUP BY EXTRACT(DAY FROM timestamp)  
    ORDER BY EXTRACT(DAY FROM timestamp) ;
    """
query34="""SELECT 
    (SELECT SUM(CAST(de.value AS NUMERIC)) FROM deviceevents de 
     INNER JOIN devices d ON de.deviceid = d.deviceid 
     INNER JOIN servicelocations sl ON d.locationid = sl.locationid 
     WHERE sl.customerid = %s) AS user_consumption,
    (SELECT SUM(CAST(de.value AS NUMERIC)) FROM deviceevents de) AS total_consumption;"""

query35= """
        SELECT 
            d.type,
            SUM(CAST(de.value AS FLOAT)) AS total_energy
        FROM 
            deviceevents de
        INNER JOIN 
            devices d ON de.deviceid = d.deviceid
        INNER JOIN 
            servicelocations sl ON d.locationid = sl.locationid
        INNER JOIN 
            customers c ON sl.customerid = c.customerid
        WHERE 
            c.username = %s  -- Replace with actual username
            AND EXTRACT(MONTH FROM de.timestamp) = %s
            AND EXTRACT(YEAR FROM de.timestamp) = %s  -- Replace with the target year (e.g., 2022)
        GROUP BY 
            d.type
        ORDER BY 
            d.type;
        """
query36="""SELECT sl.locationid,a.addressline1, a.addressline2, a.city, a.state, a.country
    FROM address a
    JOIN servicelocations sl on sl.addressid = a.addressid 
    JOIN customers c on sl.customerid = c.customerid
    WHERE c.username = %s;"""
query37="""
   SELECT COUNT(DISTINCT d.deviceid) AS total_device_count,
        d.type as devicetype
        FROM devices d
        JOIN servicelocations sl ON d.locationid = sl.locationid
        WHERE sl.locationid = %s
        group by d.type;
    """

query38="""CREATE TEMPORARY TABLE IF NOT EXISTS temp_session_costs AS
        WITH DeviceEventsWithLag AS (
            SELECT 
                DeviceID,
                Timestamp,
                Value::DECIMAL AS EnergyUsed,
                LAG(Timestamp) OVER (PARTITION BY DeviceID ORDER BY Timestamp) AS PrevTimestamp
            FROM 
                DeviceEvents
            WHERE 
                DeviceID = %s AND DATE(Timestamp) = %s
        ),
        SessionGroups AS (
            SELECT 
                DeviceID,
                Timestamp,
                EnergyUsed,
                CASE 
                    WHEN PrevTimestamp IS NULL OR Timestamp - PrevTimestamp > INTERVAL '1 hour' THEN 1
                    ELSE 0 
                END AS NewSession
            FROM 
                DeviceEventsWithLag
        ),
        SessionsWithCumulativeSum AS (
            SELECT 
                DeviceID,
                Timestamp,
                EnergyUsed,
                SUM(NewSession) OVER (PARTITION BY DeviceID ORDER BY Timestamp) AS SessionID
            FROM 
                SessionGroups
        ),
        SessionCosts AS (
            SELECT 
                DeviceID,
                SessionID,
                MIN(Timestamp) AS SessionStartTime,
                MAX(Timestamp) AS SessionEndTime,
                SUM(EnergyUsed) AS TotalEnergyUsed,
                SUM(EnergyUsed * ep.PricePerKWh) AS TotalCost
            FROM 
                SessionsWithCumulativeSum
            INNER JOIN 
                EnergyPricing ep ON DATE(Timestamp) = DATE(ep.Time) AND EXTRACT(HOUR FROM Timestamp) = EXTRACT(HOUR FROM ep.Time)
            GROUP BY 
                DeviceID, SessionID
        )
        SELECT 
            DeviceID,
            SessionID,
            SessionStartTime,
            SessionEndTime,
            TotalEnergyUsed,
            TotalCost
        FROM 
            SessionCosts;

        -- Find the cheapest times for each session
        WITH CheapestTimes AS (
            SELECT 
                tc.DeviceID,
                tc.SessionID,
                tc.SessionStartTime,
                tc.SessionEndTime,
                tc.TotalEnergyUsed AS OriginalTotalEnergyUsed,
                tc.TotalCost AS OriginalTotalCost,
                ep.Time AS CheapestTime,
                SUM(tc.TotalEnergyUsed * ep.PricePerKWh) AS CheapestTotalCost
            FROM 
                temp_session_costs tc
            CROSS JOIN 
                EnergyPricing ep
            WHERE 
                tc.DeviceID = 7
            GROUP BY 
                tc.DeviceID, tc.SessionID, tc.SessionStartTime, tc.SessionEndTime, ep.Time, tc.TotalEnergyUsed, tc.TotalCost
        )
        SELECT 
            ct.DeviceID,
            ct.SessionStartTime,
            ct.OriginalTotalCost,
            ct.CheapestTime,
            ct.CheapestTotalCost
        FROM 
            CheapestTimes ct
        WHERE 
            ct.CheapestTotalCost = (
                SELECT 
                    MIN(CheapestTotalCost)
                FROM 
                    CheapestTimes
                WHERE 
                    DeviceID = ct.DeviceID
                    AND SessionID = ct.SessionID
                    AND SessionStartTime = ct.SessionStartTime
            )
        ORDER BY 
            ct.SessionStartTime, ct.CheapestTime;
        """