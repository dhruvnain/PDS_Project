from flask import Flask, render_template
from helper.sql_helper import query_db

app = Flask(__name__)
print(app)
@app.route('/')
def index():
    data = query_db("SELECT * FROM customers")  # Adjust the query as needed
    print(data)
    return render_template('index.html', data=data)

if __name__ == '__main__':
    app.run(debug=True)
